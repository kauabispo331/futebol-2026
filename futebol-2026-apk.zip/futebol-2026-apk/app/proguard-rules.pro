# No custom ProGuard rules for the beta build.
