# Futebol 2026 — APK Android

Versão Android do jogo **Futebol 2026**, com modo Amistoso e modo Editar Beta.

## Gerar o APK

### Android Studio

1. Abra esta pasta no Android Studio.
2. Aguarde a sincronização do Gradle.
3. Acesse **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
4. O APK de teste ficará em `app/build/outputs/apk/debug/app-debug.apk`.

### GitHub Actions

O workflow em `.github/workflows/build-apk.yml` gera automaticamente um APK de teste sempre que o projeto for enviado ao GitHub. O arquivo aparece na aba **Actions**, como artefato do workflow.

## Requisitos

- Android Studio recente
- Android SDK 35
- JDK 17

O jogo funciona offline e guarda as edições dos times no armazenamento local do aplicativo.
